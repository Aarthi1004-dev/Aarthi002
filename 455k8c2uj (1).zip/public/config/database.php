<?php
$host = "db01.dbhost.dev";
$port = 5051;
$username = "user_455k84x4c";
$password = "p455k84x4c";
$database = "db_455k84x4c";

$conn = new mysqli($host, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
