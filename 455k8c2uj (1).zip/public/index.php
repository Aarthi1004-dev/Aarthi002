<?php
session_start();

if (isset($_SESSION["user_id"])) {
    if ($_SESSION["role"] == "student") {
        header("Location: student/dashboard.php");
        exit();
    }

    header("Location: company/dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InternHub - College Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="index.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <a href="login.php">Sign In</a>
            <a class="nav-button" href="register.php">Create Account</a>
        </div>
    </nav>

    <main class="hero">
        <div class="hero-content">
            <div class="badge">COLLEGE INTERNSHIP APPLICATION PORTAL</div>
            <h1>Find your next <span>opportunity.</span></h1>
            <p>
                A simple and professional platform for students to discover internships,
                apply online, and track every stage of their application.
            </p>
            <div class="hero-actions">
                <a class="button primary" href="register.php">Get Started</a>
                <a class="button secondary" href="login.php">Sign In</a>
            </div>
        </div>

        <div class="hero-card">
            <div class="mini-label">APPLICATION JOURNEY</div>
            <div class="timeline">
                <div class="timeline-item active"><span>1</span><div><strong>Applied</strong><small>Application submitted</small></div></div>
                <div class="timeline-item"><span>2</span><div><strong>Under Review</strong><small>Company is reviewing</small></div></div>
                <div class="timeline-item"><span>3</span><div><strong>Shortlisted</strong><small>Selected for next stage</small></div></div>
                <div class="timeline-item"><span>4</span><div><strong>Interview</strong><small>Interview stage</small></div></div>
                <div class="timeline-item"><span>5</span><div><strong>Selected</strong><small>Final result</small></div></div>
            </div>
        </div>
    </main>

    <section class="features">
        <div class="feature-card"><div class="feature-icon">01</div><h3>Student Profiles</h3><p>Create a profile, add skills and upload your resume.</p></div>
        <div class="feature-card"><div class="feature-icon">02</div><h3>Internship Search</h3><p>Search and filter opportunities based on your interests.</p></div>
        <div class="feature-card"><div class="feature-icon">03</div><h3>Application Tracking</h3><p>Track your application from Applied to Selected or Rejected.</p></div>
    </section>

    <footer>© 2026 InternHub College Internship Portal</footer>
</body>
</html>
