<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "company") {
    header("Location: ../login.php");
    exit();
}

$company_stmt = $conn->prepare("SELECT id FROM companies WHERE user_id = ?");
$company_stmt->bind_param("i", $_SESSION["user_id"]);
$company_stmt->execute();
$company = $company_stmt->get_result()->fetch_assoc();

$company_id = $company["id"];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $application_id = intval($_POST["application_id"]);
    $new_status = $_POST["status"];

    $allowed_statuses = ["Applied", "Under Review", "Shortlisted", "Interview", "Selected", "Rejected"];

    if (in_array($new_status, $allowed_statuses)) {
        $update = $conn->prepare(
            "UPDATE applications
            JOIN internships ON applications.internship_id = internships.id
            SET applications.status = ?
            WHERE applications.id = ? AND internships.company_id = ?"
        );
        $update->bind_param("sii", $new_status, $application_id, $company_id);
        $update->execute();
        $message = "Application status updated successfully.";
    }
}

$list = $conn->prepare(
    "SELECT applications.id, applications.status, applications.applied_at,
    users.name, users.email, students.phone, students.skills,
    internships.title
    FROM applications
    JOIN students ON applications.student_id = students.id
    JOIN users ON students.user_id = users.id
    JOIN internships ON applications.internship_id = internships.id
    WHERE internships.company_id = ?
    ORDER BY applications.applied_at DESC"
);
$list->bind_param("i", $company_id);
$list->execute();
$applicants = $list->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applicants - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links"><a href="dashboard.php">Dashboard</a><a href="add_internship.php">Add Internship</a><a href="internships.php">My Internships</a><a href="../logout.php">Logout</a></div>
    </nav>

    <main class="container">
        <div class="page-heading"><div><div class="badge">APPLICATION MANAGEMENT</div><h1>Applicants</h1><p>Review students and move applications through the recruitment workflow.</p></div></div>

        <?php if ($message != ""): ?><div class="alert success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>

        <div class="table-wrap">
            <table>
                <thead><tr><th>Student</th><th>Internship</th><th>Skills</th><th>Status</th><th>Update</th></tr></thead>
                <tbody>
                    <?php if ($applicants->num_rows == 0): ?>
                        <tr><td colspan="5">No applications received yet.</td></tr>
                    <?php endif; ?>

                    <?php while ($row = $applicants->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($row["name"]); ?></strong><br><small><?php echo htmlspecialchars($row["email"]); ?></small></td>
                            <td><?php echo htmlspecialchars($row["title"]); ?></td>
                            <td><?php echo htmlspecialchars($row["skills"] ?? "Not added"); ?></td>
                            <td><span class="status <?php echo strtolower(str_replace(" ", "-", $row["status"])); ?>"><?php echo htmlspecialchars($row["status"]); ?></span></td>
                            <td>
                                <form method="POST" class="status-form">
                                    <input type="hidden" name="application_id" value="<?php echo $row["id"]; ?>">
                                    <select name="status">
                                        <?php
                                        $statuses = ["Applied", "Under Review", "Shortlisted", "Interview", "Selected", "Rejected"];
                                        foreach ($statuses as $status):
                                        ?>
                                            <option value="<?php echo $status; ?>" <?php echo $row["status"] == $status ? "selected" : ""; ?>><?php echo $status; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button class="small-button" type="submit">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
